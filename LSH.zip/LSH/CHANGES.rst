v0.0.3, 2012/12/28 -- Doc fixes.
v0.0.2, 2012/12/28 -- Doc fixes and lowercase package name.
v0.0.1, 2012/12/20 -- Initial release.
